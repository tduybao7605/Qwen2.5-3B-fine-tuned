package com.baxailab.cadebot.ui.ai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.baxailab.cadebot.data.mock.MockAiService
import com.baxailab.cadebot.data.mock.MockMenuService
import com.baxailab.cadebot.data.model.AiMessage
import com.baxailab.cadebot.data.model.CartItem
import com.baxailab.cadebot.data.model.MenuItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AiUiState(
    val messages: List<AiMessage> = emptyList(),
    val isTyping: Boolean = false,
    val inputText: String = "",
    val recommendedItems: List<MenuItem> = emptyList()
)

@HiltViewModel
class AiViewModel @Inject constructor(
    private val aiService: MockAiService,
    private val menuService: MockMenuService
) : ViewModel() {

    private val _uiState = MutableStateFlow(AiUiState())
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    private val allItems by lazy { menuService.getMenu().items }

    init {
        val greeting = aiService.getGreeting()
        _uiState.value = _uiState.value.copy(messages = listOf(greeting))
    }

    fun onInputChange(text: String) {
        _uiState.value = _uiState.value.copy(inputText = text)
    }

    fun sendMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isEmpty()) return

        val userMsg = AiMessage(content = text, isUser = true)
        _uiState.value = _uiState.value.copy(
            messages = _uiState.value.messages + userMsg,
            inputText = "",
            isTyping = true
        )

        viewModelScope.launch {
            delay(800)
            val response = aiService.processQuery(text)
            val recommended = allItems.filter { it.menuItemId in response.recommendedItems }
            _uiState.value = _uiState.value.copy(
                messages = _uiState.value.messages + response,
                isTyping = false,
                recommendedItems = recommended
            )
        }
    }

    fun sendQuickQuery(query: String) {
        _uiState.value = _uiState.value.copy(inputText = query)
        sendMessage()
    }
}
