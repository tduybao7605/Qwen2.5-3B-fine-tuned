package com.baxailab.cadebot.di

import android.content.Context
import com.baxailab.cadebot.data.mock.MockAiService
import com.baxailab.cadebot.data.mock.MockMenuService
import com.baxailab.cadebot.data.mock.MockOrderService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideMenuService(@ApplicationContext ctx: Context) = MockMenuService(ctx)

    @Provides
    @Singleton
    fun provideAiService(@ApplicationContext ctx: Context) = MockAiService(ctx)

    @Provides
    @Singleton
    fun provideOrderService() = MockOrderService()
}
